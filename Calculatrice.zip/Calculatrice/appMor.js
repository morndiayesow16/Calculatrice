// recupérer les elements du DOM (Document Objet Model) est une interface de programmation
const touches = [...document.querySelectorAll('.bouton')]; /* pour recupérer tous les éléments sous forme de tableau*/
 /* site keycode.info */
const listeKeycode = touches.map(touche => touche.dataset.key);  //Crée un nouveau tableau avec le résultat de 
                                                                 //l'appel d'une fonction pour chaque élément du tableau
const ecran = document.querySelector('.ecran');
//touche 6 : keycode: 102
document.addEventListener('keydown', (e) =>{
    const valeur = e.keyCode.toString();
    calculer(valeur)
})

document.addEventListener('click', function(e){
    const valeur = e.target.dataset.key;
    calculer(valeur)
})

const calculer = (valeur) => {
    if(listeKeycode.includes(valeur)){ 
    switch (valeur) {
        case '8':
            ecran.textContent = "";
            break;

        case '13':
            const calcul = eval(ecran.textContent);
            ecran.textContent = calcul;
            break;
        default :
            const indexKeycode = listeKeycode.indexOf(valeur); //fonction indexOf c'est pour rechercher un élément
            const touche = touches[indexKeycode];
            ecran.textContent += touche.innerHTML;
        }
    } 

}
window.addEventListener('error', (e) => {
    alert('Y a une erreur dans votre calcul : ' + e.message)
})